import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  jsonFormValid: boolean;
  jsonFormObject: any;
  liveFormData: {};
  formActive: boolean;
  jsonFormStatusMessage: string;
  title = 'app';
  /**
   * To handle the custom validation messages
   */
  jsonFormOptions: any = {
    addSubmit: true, // Add a submit button if layout does not have one
    debug: false, // Don't show inline debugging information
    loadExternalAssets: true, // Load external css and JavaScript for frameworks
    returnEmptyFields: false, // Don't return values for empty input fields
    setSchemaDefaults: true, // Always use schema defaults for empty fields
    defautWidgetOptions: { feedback: true }, // Show inline feedback icons
  };
  submittedFormData: any = null;
  selectedExample = '';
  jsonFormSchema = {};
  exampleURL = `assets/example-schemas/${this.selectedExample}.json`;

  constructor(private http: HttpClient) {
    this.http
      .get(this.exampleURL, { responseType: 'text' })
      .subscribe(schema => {
        this.jsonFormSchema = schema;
        this.generateForm(JSON.stringify(this.jsonFormSchema));
      });
  }

  /**
  * [Json schema form]
  * @link {https://github.com/dschnelldavis/angular2-json-schema-form}
  * @example schema
   * let yourCompoundInputObject = {
   *
   * schema:    { ... },  // required
   *
   * layout:    [ ... ],  // optional
   *
   * data:      { ... },  // optional
   *
   * options:   { ... },  // optional
   *
   * widgets:   { ... },  // optional
   *
   * framework: { ... }   // optional  }
   */

  /**
  * To hold the schema of model and form elements
  */
  connectorJsonSchema: any = {
    'schema': {
      'type': 'object',
      'properties': {
        'ServerName': {
          'title': 'ServerName*: ',
          'htmlClass': 'form-group',
          'type': 'string'
        },
        'Port': {
          'title': 'Port*: ',
          'type': 'string'
        },
        'SID': {
          'title': 'SID: ',
          'type': 'string'
        },
        'ServiceName': {
          'title': 'ServiceName',
          'type': 'string'
        },
        'WindowsAuthentication': {
          'title': 'Enable Windows Authentication',
          'type': 'boolean',
          'default': false
        },
        'UserName': {
          'title': 'UserName*: ',
          'type': 'string'
        },
        'Password': {
          'title': 'Password*: ',
          'type': 'string'
        }
      },
      'required': ['ServerName', 'Port', 'UserName', 'Password']
    },
    'form': [
      {
        'type': 'section',
        'htmlClass': 'col-md-12',
        'items': [
          {
            'key': 'ServerName',
            'type': 'string',
            'minLength': 4,
            'placeholder': 'Enter your server name or IP address',
            'validateMessages': {
              'required': 'It is reqired field!',
              'minLength': 'Minlength of this field is 4 symbols!'
            }
          },
          {
            'key': 'Port',
            'type': 'string',
            'minLength': 4,
            'maxLength': 6,
            'placeholder': 'Enter Port number',
            'validateMessages': {
              'required': 'It is reqired field!',
              'minLength': 'Minlength of this field is 4 symbols!',
              'maxLength': 'Maxlength of this field is 10 symbols!'
            }
          },
          {
            'key': 'SID',
            'type': 'string',
            'validateMessages': {
              'required': 'It is reqired field!'
            }
          },
          {
            'key': 'ServiceName',
            'type': 'string',
            'minLength': 4,
            'validateMessages': {
              'required': 'It is reqired field!',
              'minLength': 'Minlength of this field is 4 symbols!'
            }
          },
          'WindowsAuthentication',
          {
            'type': 'conditional',
            'condition': 'modelData.WindowsAuthentication==false',
            'items': [
              {
                'key': 'UserName',
                'type': 'string',
                'minLength': 4,
                'placeholder': 'Enter user name to connect with the Oracle',
                'validateMessages': {
                  'required': 'It is reqired field!',
                  'minLength': 'Minlength of this field is 4 symbols!'
                }
              },
              {
                'key': 'Password',
                'type': 'password',
                'minLength': 4,
                'placeholder': '*******',
                'validateMessages': {
                  'required': 'It is reqired field!',
                  'minLength': 'Minlength of this field is 4 symbols!'
                }
              }
            ]
          },
          {
            'type': 'submit',
            'htmlClass': 'col-md-6',
            'fieldHtmlClass': 'btn btn-success pull-right',
            'title': 'Connect'
          },
          {
            'type': 'reset',
            'htmlClass': 'col-md-1',
            'fieldHtmlClass': 'btn btn-default',
            'title': 'Clear'
          }
        ]
      }
    ]
  };

  schmaes = {
    'schema': {
      'type': 'object',
      'properties': {
        'select': {
          'title': 'Select without titleMap',
          'type': 'string',
          'enum': ['a', 'b', 'c']
        },
        'select2': {
          'title': 'Select with titleMap (old style)',
          'type': 'string',
          'enum': ['a', 'b', 'c']
        },
        'noenum': {
          'type': 'string',
          'title': 'No enum, but forms says it\'s a select'
        },
        'array': {
          'title': 'Array with enum defaults to \'checkboxes\'',
          'type': 'array',
          'items': {
            'type': 'string',
            'enum': ['a', 'b', 'c']
          }
        },
        'array2': {
          'title': 'Array with titleMap',
          'type': 'array',
          'default': ['b', 'c'],
          'items': {
            'type': 'string',
            'enum': ['a', 'b', 'c']
          }
        },
        'radios': {
          'title': 'Basic radio button example',
          'type': 'string',
          'enum': ['a', 'b', 'c']
        },
        'radiobuttons': {
          'title': 'Radio buttons used to switch a boolean',
          'type': 'boolean',
          'default': false
        }
      }
    },
    'form': [
      'select',
      {
        'key': 'select2',
        'type': 'select',
        'titleMap': {
          'a': 'A',
          'b': 'B',
          'c': 'C'
        }
      },
      {
        'key': 'noenum',
        'type': 'select',
        'titleMap': [
          { 'value': 'a', 'name': 'A' },
          { 'value': 'b', 'name': 'B' },
          { 'value': 'c', 'name': 'C' }
        ]
      },
      'array',
      {
        'key': 'array2',
        'type': 'checkboxes',
        'titleMap': [
          { 'value': 'a', 'name': 'A' },
          { 'value': 'b', 'name': 'B' },
          { 'value': 'c', 'name': 'C' }
        ]
      },
      {
        'key': 'radios',
        'type': 'radios',
        'titleMap': [
          { 'value': 'c', 'name': 'C' },
          { 'value': 'b', 'name': 'B' },
          { 'value': 'a', 'name': 'A' }
        ]
      },
      {
        'key': 'radiobuttons',
        'type': 'radiobuttons',
        'titleMap': [
          { 'name': 'No way', 'value': false },
          { 'name': 'OK', 'value': true }
        ]
      }
    ]
  };
  /**
   * Model data that matches json schema properties
   */
  connectorData = {
    'ServerName': '',
    'Port': '',
    'SID': '',
    'ServiceName': '',
    'WindowsAuthentication': false,
    'UserName': '',
    'Password': ''
  };

  generateForm(newFormString: string) {
    if (!newFormString) { return; }
    this.jsonFormStatusMessage = 'Loading form...';
    this.formActive = false;
    this.liveFormData = {};
    this.submittedFormData = null;
    // Most examples should be written in pure JSON,
    // but if an example schema includes a function,
    // it will be compiled it as Javascript instead
    try {

      // Parse entered content as JSON
      this.jsonFormObject = JSON.parse(newFormString);
      this.jsonFormValid = true;
    } catch (jsonError) {
      try {

        // If entered content is not valid JSON,
        // parse as JavaScript instead to include functions
        let newFormObject: any = null;
        /* tslint:disable */
        eval('newFormObject = ' + newFormString);
        /* tslint:enable */
        this.jsonFormObject = newFormObject;
        this.jsonFormValid = true;
      } catch (javascriptError) {

        // If entered content is not valid JSON or JavaScript, show error
        this.jsonFormValid = false;
        this.jsonFormStatusMessage =
          'Entered content is not currently a valid JSON Form object.\n' +
          'As soon as it is, you will see your form here. So keep typing. :-)\n\n' +
          'JavaScript parser returned:\n\n' + jsonError;
        return;
      }
    }
  }
  /**
   * To handle the form submit
   * @param receives event emited from library
   */
  fnSubmit(data: any) {
    this.submittedFormData = data;
    console.log('Validate' + data);
  }

  /**
   * To handle the model validation
   * @param validator
   */
  fnValidate($event) {
    console.log('Validate' + $event);
  }

  /**
   * To handle the on changes of a model property
   * @param  receives changes as model
   */
  fnChanges($event) {
    console.log('Changes' + $event);
  }

}
